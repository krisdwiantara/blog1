---
title: "2 Minggu Tanpa Coding"
slug: isra-mikraj-2018
date: 2018-04-06T22:47:33+08:00
draft: false

type: post

tags:
    - tag

image: "/img/isra-mikraj/panitia.jpg"
description: "Dua minggu ini saya tidak pernah nge-push ke Github, karena sibuk menjadi panitia"
---

Dua minggu ini saya nggak pernah coding,
karena acara lomba dalam rangka peringatan Isra' Mikraj.

Saya menjadi panitia di acara ini.

Selama dua minggu ini, jarang online...

...karena acara selesai sampai jam 10, dan beres-beres
sampai jam 12.

Akun github saya menjadi sepi.

![Aktivitas di Github](/img/isra-mikraj/github.png)

Tapi yang seru di acara ini:

Bisa ngopi bareng teman-teman.

![Ngopi Bareng setelah selesai acara](/img/isra-mikraj/panitia.jpg)

Bisa merasakan "lelahnya" menjadi panitia.

![Sticker Isra Mikraj](/img/isra-mikraj/sticker.jpg)

dan masih banyak lagi.