---
title: "8 Tempat Nonton Anime Secara Legal di Indonesia"
slug: anime-legal-indonesia
date: 2020-10-14T18:38:56+08:00
draft: true

type: post

tags:
    - anime

image: ""
description: ""
typora-root-url: ../../static
---

## 1. TV Lokal

> Biaya: Gratis

Beberapa chanel TV di indonesia ada yang menayangkan Anime. Setau saya dulu ada beberapa channel yang pernah menayangkan anime: Global TV, RCTI, dan Rajawali TV (RTV).

Anime yang ditayangkan biasanya anime populer seperti Naruto dan One Piece. Anime-nya juga sudah dilakukan dubbing ke bahasa indonesia dan tentunya lulus sensor.

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fweb.facebook.com%2FlangitRTV%2Fposts%2F4121181444618614&show_text=true&width=552&appId=1859589104297777&height=673" width="552" height="673" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## 2. Bioskop

> Biaya: 60rb/tiket

Beberapa anime movie sering ditayang di Bioskop. Biasanya ditayangkan di CGV dengan harga tiket sekitar 60rb.

## 3. Netflix

> Biaya: sekitar 54rb/bulan

Netflix adalah platform streaming movie. Netflix juga menyediakan konten-konten anime. Biaya untuk belangganan sekitar 54rb/bulan. Belum ditambah biaya kuota hehe.

Pilihan anime di Netflix juga beragam dan banyak. Kita bisa cari dalam genre [Anime](https://www.netflix.com/id/browse/genre/7424).

![anime di netflix](/img/anime-legal-indonesia/anime-netflix.png)

## 4. Iflix

> Biaya: 39rb/bulan

Nah, kalau Iflix sebenarnya sama seperti Netflix. Hanya saja Netflix bisa diakses secara global. Sedangkan Iflix hanya tersedia di beberapa negara asia seperti Indonesia, Malaysia, Filipina, Tailand, dll.

Awal mula saya tau Iflix, sejak ada paket kuota iflix di XL. Karena sia-sia paket tersebut tidak terpakai, maka saya instal Iflix, hehe.

![anime di iflix](/img/anime-legal-indonesia/anime-iflix.png)

Nah, dulunya ada banyak pilihan anime di Iflix, tapi sekarang malah berkurang. Animenya tinggal sedikit. Dulu ada New Game seasion 1 dan 2, sekarang sudah tiada.

Biaya langganan Iflix memang lebih murah daripada Netflix, tapi konten anime yang bisa ditoton sedikit.

## 5. Sushiroll/Genflix

> Biaya Sushiroll: sekitar 13.750/bulan (sumber: tokopedia)

Genflix sama juga seperti Netflix dan Iflix, hanya saja dibuat oleh Indonesia. Beberapa konten anime di Genflix bersumber dari Sushiroll.

Buat kamu yang hanya ingin menikmati anime saja, saya sarankan menggunakan Sushiroll, tapi jika ingin menikmati konten lain.. bisa pilih Genflix.

Menurut saya, lebih enak Sushiroll, karena biaya langanannya juga terjangkau sekitar 13rb/bulan.

![anime sushiroll](/img/anime-legal-indonesia/anime-sushiroll.png)

## 6. Crunchyroll

Crunchyroll ini juga sama seperti Sushiroll. Hanya saja Suhiroll buatan orang indonesia, sedangkan Crunchyroll buatan orang luar. Pilihan anime di Crunchyroll juga beragam dan banyak.



## 7. Youtube Muse Channel

> Biaya: Free

Saya baru dengar tentang channel ini beberapa hari yang lalu. Saat itu, tiba-tiba direkomendasikan video anime di Youtube.

Saya berpikir, kok ini bisa ada di Youtube dan nggak melanggar copyright.

Setelah saya telusuri, ternyata channel ini menyediakan konten anime secara legal. Anime yang tayang juga terupdate, mengikuti jam tayang di jepang.

Muse Channel ini punya beberapa cabang, ada Muse Indonesia, Muse Malaysia, Muse Asia.

Saya hanya subscribe Muse Indonesia dan Muse Asia. Muse Indonesia, untuk anime dengan subtitle Indonesia dan yang Asia untuk bahasa inggris dan bahasa lainnya.

## 8. Amazon Prime

## Akhir Kata..