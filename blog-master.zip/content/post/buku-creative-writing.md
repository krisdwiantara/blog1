---
title: "[Challenge 2018] Buku #1: Craetive Writing"
slug: buku-creative-writing
date: 2018-02-19T20:15:20+08:00
draft: false

type: post

tags:
    - buku

image: "/img/buku/creative-writing.jpg"
description: "Buku ini berisi tips dan panduan menulis karya fiksi. Diawali dengan fundamental cara menulis yang benar. Lalu diajari cara menulis plot, dialog, narasi, dan lain-lain."
---

Buku ini adalah buku pertama yang saya selesaikan tahun ini.
Sebenarnya mulai dibaca sejak tahun lalu, namun 
karena tidak pernah dibuka lagi, jadi terbengkalai 😄.

Buku ini saya beli di Playstore dengan
harga yang sangat murah. Karena saat itu sedang 
ada diskon besar-besaran.

Bayarnya via pulsa. Asik kan.

Sebenarnya pingin juga punya versi cetaknya,
buat dijadikan koleksi.

Buku ini biasanya saya baca saat mau tidur untuk
memancing rasa ngantuk.

Bukan karena bukunya membosankan, namun biasanya
saya kalau baca buku akan mengantuk 😄.

Mungkin karena belum terbiasa membaca buku.

## Apa yang dibahas di dalam buku ini?

Buku ini tidak ada kaitannya dengan dunia IT.
Tapi saya butuh isinya untuk meningkatkan wawasan
seputar tulis-menulis.

Buku ini berisi tips dan panduan menulis karya
fiksi.

Diawali dengan fundamental cara menulis yang
benar. Lalu diajari cara menulis plot, dialog,
narasi, dan lain-lain.

Buku ini dilengkapi dengan contoh studi
kasus dari beberapa novel terkenal.

Buku ini sudah menyadari saya...

...ternyata selama
ini [saya salah dalam menulis](/blog/menulis-blog/).

Namun ada bab yang tidak saya temukan pada buku
ini, yaitu bab tentang editing.

<!-- Embed review Goodread -->

Mungkin penulisnya lupa atau mungkin kita
yang harus menemukan sendiri cara editing.

---

<a href="https://www.goodreads.com/book/show/19523721-creative-writing" style="float: left; padding-right: 20px"><img border="0" alt="Creative Writing: Tip dan Strategi Menulis Cerpen dan Novel - Edisi Revisi" src="https://images.gr-assets.com/books/1387272889m/19523721.jpg" /></a><a href="https://www.goodreads.com/book/show/19523721-creative-writing">Creative Writing: Tip dan Strategi Menulis Cerpen dan Novel - Edisi Revisi</a> by <a href="https://www.goodreads.com/author/show/972718.A_S_Laksana">A.S. Laksana</a><br/>
My rating: <a href="https://www.goodreads.com/review/show/2284398828">4 of 5 stars</a><br /><br />
Bab editing tidak ada
<br/><br/>
<a href="https://www.goodreads.com/review/list/22658052-ardianta-pargo">View all my reviews</a>

---

...dan sekarang sudah bulan Februari,
artinya tinggal 11 bulan lagi untuk menyelesaikan
[target membaca 10 buku dalam setahun](https://www.goodreads.com/user_challenges/10642577).