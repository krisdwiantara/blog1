---
title: "Hasil Latihan Menggambar Menggunakan Pen Tablet Wacom Selama 1 Minggu"
slug: wacom
date: 2018-05-14T10:38:39+08:00
draft: false

type: post

tags:
    - Art
    - Drawing

image: "/img/wacom/wacom-intuos.jpg"
description: "Pada awal-awal menggunakan pen tablet memang sulit. Namun, semakin sering latihan...semakin gampang."
---

Hari sabtu tanggal 3 Mei kemarin, saya membeli pen tablet wacom milik
teman saya.

Wacom model Intuos CTH-480.

![Wacom CTH-480](/img/wacom/wacom-intuos.jpg)

Ini memang model lama, Dia beli skitar 3 tahun yang lalu.
Namun, tidak pernah dipakai.

## Pengalaman Pertama Menggunakan Wacom

Dulu saya memang pernah mencoba wacom ini,
hasilnya:

![Hasil Gambar Pertama Menggunakan Wacom](https://img00.deviantart.net/1ba3/i/2018/105/2/a/the_north_beach_by_ardiantapargo-dc8wbrh.jpg)

Ini saya gambar sekitar 3 tahun yang lalu...

Sekarang saya mencoba lagi menggunakan Wacom.

Hasilnya:

## Sabtu, 05 Mei 2018

Gambar Pertama:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2166136263403734&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Gambar Kedua:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fphoto.php%3Ffbid%3D2166159326734761%26set%3Da.2137664869584207.1073741834.100000221442854%26type%3D3&width=500" width="500" height="292" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Gambar Ketiga:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fphoto.php%3Ffbid%3D2166205080063519%26set%3Da.2137664869584207.1073741834.100000221442854%26type%3D3&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Saya mencoba menggambar menggunakan MyPaint dan Krita.

## Minggu, 06 Mei 2018

Besoknya saya coba dengan aplikasi yang berbeda, yaitu GIMP.

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fphoto.php%3Ffbid%3D2166260006724693%26set%3Da.2137664869584207.1073741834.100000221442854%26type%3D3&width=500" width="500" height="423" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Mencoba belajar mewarnai:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2167254169958610&width=500" width="500" height="750" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Latihan membuat garis di MyPaint:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2166805876670106&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2167174076633286&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Senin, 07 Mei 2018

Di hari ke-3 mulai pusing, karena ada beberapa job yang belum dikerjakan.

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2168271373190223&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Selasa, 08 Mei 2018

Hari berikutnya... masih pusing dengan job yang belum selesai. 😄

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2168601596490534&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Rabu, 09 Mei 2018

Hari berikutnya, membuat garis dan mewarnai.

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2169200343097326&width=500" width="500" height="725" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Mencoba style chibi, karena habis melihat tutorial menggambar
karakter chibi di Youtube.

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2169313579752669&width=500" width="500" height="408" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Latihan membuat garis:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2169676786383015&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Latihan Lagi:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2169758573041503&width=500" width="500" height="292" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Latihan Shading dan Lighting:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2170071736343520&width=500" width="500" height="383" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Istirahat menggambar dengan Wacom, kali ini saya menggunakan HP dengan jari di aplikasi Medibang Paint:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2170459572971403&width=500" width="500" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Mencoba lagi...

Belajar Shading, Lighting, dan membuat Line Art:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2170667232950637&width=500" width="500" height="776" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Kamis, 10 Mei 2018

Mencoba menggambar diri sendiri:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2171457876204906&width=500" width="500" height="426" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Mencoba menggambar karakter cowok:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2171881306162563&width=500" width="500" height="433" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Jum'at, 11 Mei 2018

Membuat video proses menggambar:

{{< youtube XfQwzzPDlJc >}}

Menggambar karakter untuk digunakan di Petani Kode:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2172645296086164&width=500" width="500" height="376" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

...dan membuat videonya:

{{< youtube pwrxVzH-lAo >}}


Latihan menggambar di HP:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2172691569414870&width=500" width="500" height="595" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Sabtu, 12 Mei 2018

Mencoba melukis pemandangan:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2174280525922641&width=500" width="500" height="464" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Belajar menggambar karakter untuk komik:

![Karakter komik](/img/wacom/komik-strip.png)

## Minggu, 13 Mei 2018

Menggambar karakter Sylvia (Linux Mint Sylvia)

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2174526699231357&width=500" width="500" height="376" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Hasil akhirnya berupa wallpaper, bisa di-download di sini: http://fav.me/dcbek3x

Latihan menggambar karakter chibi:

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2175541982463162&width=500" width="500" height="292" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

Menggambar karakter dari foto (challenge dari grup gambar):

![Menggambar anime dari foto](/img/wacom/tantangan-group.png)

Belajar menggambar dua karakter:

![menggambar dua karakter](/img/wacom/dua-karakter.png)

<iframe src="https://www.facebook.com/plugins/post.php?href=https%3A%2F%2Fwww.facebook.com%2Fardianta.pargo%2Fposts%2F2176245842392776&width=500" width="500" height="427" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>

## Akhir Kata...

Itulah hasil latihan menggambar menggunakan Wacom selama seminggu.
Sebenarnya masih banyak lagi yang belum saya upload.

Rata-rata mungkin saya menghabiskan waktu 1 jam untuk menyelesaikan gambar
yang berwarna. Sementara untuk sektsa dan line art, sekitar 30 menit bisa.

Pada awal-awal menggunakan pen tablet memang sulit.
Namun, semakin sering latihan...semakin gampang.

Saya sendiri masih belum terlalu menguasai, tapi untuk saat ini
sudah mulai terbiasa.

Dari gambar-gambar yang sudah saya buat,
Saya bisa melihat kekurangan dan kesalahanya.

Seperti shading dan lighting yang kurang tepat,
line art yang kurang halus.

...dan sebagainya.

![Terluslah Berlatih](/img/wacom/terus-berlatih.png)