---
title: "Evaluasi Livestream Pertama Petanikode"
slug: livestream-pertama
date: 2018-11-18T20:24:24+08:00
draft: false

type: post

tags:
    - workshop
    - komunitas

image: "/img/workshop/android/jetpack.jpg"
description: "Pada hari minggu tanggal 18 November 2018 
telah diadakan workshop Android Jetpack di markasnya Linov."
---

Pada hari minggu ku turut ayah ke kota, eh.

Pada hari minggu tanggal 18 November 2018 
telah diadakan workshop Android Jetpack di markasnya Linov.

Acara ini disiarkan secara live di channel petanikode.

![Workshop Android Jetpack](/img/workshop/android/jetpack.jpg)

Tapi, banyak hal yang kurang.

## 1. Koneksi Internet

Koneksi internet yang digunakan untuk live stream
kurang stabil, sehingga video terputus-putus.

## 2. Sound Card Rusak

Soundcard USB rusak, untungnya ada bang Hayi yang
bisa perbaiki. Kalau tidak ada sound card ini,
mungkin livestream tidak akan bisa dilaksanakan.

## 3. Moderator

Tidak ada moderator yang mengarahkan workshop ini,
sehingga berjalan apa adanya.


Sampel hasil livestream:

{{< youtube nxJ0_IQXeU4 >}}