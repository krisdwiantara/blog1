---
title: "Melanjutkan Pembuatan Template Blogger dengan Bootstrap"
slug: template-bs4blogger
date: 2018-04-25T21:22:40+08:00
draft: false

type: post

tags:
    - Blog
    - Bootstrap

image: "/img/template-blogger/bs4blogger.png"
description: "Template ini saya persembahkan untuk kawan-kawan yang ingin membuat blognya terlihat: Bersih, Rapi, Elegan, Sederhana, dan profesional."
---

Sudah cukup lama saya [mulai pembuatan template ini](/blog/template-blogger).
Namun, belum sempat dilanjutkan lagi.

Kemarin saya coba otak-atik lagi...

...dan ini hasilnya:

![Template Blogger dengan Bootstrap](/img/template-blogger/bs4blogger.png)

Terlhat bagus 😄

Template ini sebenarnya replika dari template [Petani Kode](https://www.petanikode.com). 
Karena banyak yang meminta saya untuk membuat versi Bloggernya.

Template ini saya persembahkan untuk kawan-kawan yang ingin 
membuat blognya terlihat:

- Bersih
- Rapi
- Elegan
- Sederhana
- dan profesional.

![Coming Soon Template Petanikode untuk Blogger](https://3.bp.blogspot.com/-KzRiRE8FAtM/WuBBg6k5GzI/AAAAAAAAE8M/q7iR9_q-loUY1oZR1B_0HRmVAKcD0ipeQCK4BGAYYCw/s1600/bs4blogger-cover.png)

### Tertarik?

Cek demonya di sini: https://bs4blogger.blogspot.co.id/

Oya, template ini masih belum jadi...

Sabar ya 😄