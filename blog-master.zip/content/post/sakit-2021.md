---
title: "Sakit Pertama di 2021"
slug: sakit-2021
date: 2021-02-20T17:22:26+08:00
draft: false

type: post

tags:
    - sakit

image: "/img/sakit-2021/PIXNIO-2373067-600x400.jpg"
description: "Tepat satu minggu yang lalu, pada hari sabtu siang.. saya mulai merasa kurang enak badan."
typora-root-url: ../../static
---

Tepat satu minggu yang lalu, pada hari sabtu siang.. saya mulai merasa kurang enak badan. Mungkin karena cuaca yang kurang stabil.

Saya demam tinggi dan sakit kepala. Tidak tahan duduk terlalu lama. Pingin tiduran aja.

Padahal saat ini lagi banyak task yang harus diselesaikan.

Yah, mau bagaimana lagi.. semuanya tidak bisa ku kerjakan.

## Demam Hari pertama dan kedua

Saat awal saya merasa kurang enak badan, saya minum paracetamol. Namun dememnya tidak kunjung turun. Cuma keluar keringat, tapi demamnya masih terasa.

Takutnya ini DBD.. dan gak mau diinfus lagi.

Karena tahun lalu, saya kena DBD, gejalannya seperti ini. Tiba-tiba demam, sakit kepala, dan kurang nafsu makan.

Biasanya sakit tenggorokan dulu baru demam, tapi saat DBD kemarin langsung demam dan sakit kepala.

Akhirnya, saya coba dikasih minum daun pepaya. Rasanya pahit memang, tapi katanya itu bisa mengobati DBD.

![Daun pepaya](https://cdn.pixabay.com/photo/2017/11/01/22/37/tree-2909603__340.jpg)

## Demam Hari ke-3

Karena demamku belum turun, akhirnya pergi ke klinik. Di sana saya disuntik dan dikasih obat. Ada vitamin, obat demam dan sakit kepala, obat untuk mengurangi rasa mual dan obat alergi.

![PIXNIO-2373067-600x400](/img/sakit-2021/PIXNIO-2373067-600x400.jpg)

- Caviplex (Vitamin)
- Anflat (asam lambung, mual)
- Grathazon (Alergi, asam urat, pegal)
- Paracetamol Mirasic Forte (Demam, pusing, sakit kepala)

## Demam Hari ke-4

Pada hari ke-4, saya merasa sedikit lebih baik dengan masih ada sedikit rasa demam.

Hari ini saya mencoba untuk mandi, karena udah dua hari tiduran dan ga mandi.. ups :see_no_evil:

Malamnya hujan besar. Pada jam 02:00 pagi, saya merasa kedingingan. Sangat dingin, seperti berada di kutub selatan. Meskipun saya belum pernah ke sana hehehe.

Walau pakai selimut tebal dan baju hangat, tapi tetap merasa kedinginan. Awalnya mengira dingin ini berasal dari hujan, tapi ternyata tidak.

Tubuhku terasa panas, tapi aku merasa kedinginan. Akhirnya aku minum obat lagi. Yang ku minum adalah paracetamol, karena sebelumnya aku cuma minum vitamin saja.

Beberapa jam kemudian, aku mulai keluar keringat dan rasa dinginnya mulai hilang.

## Hari ke-5

Pada hari ke-5, saya merasa sedikit lebih baik. Tapi masih merasa kurang enak. Apalagi kalau duduk berlama-lama. Pinginnya tiduran aja.

Mungkin lagi masa penyembuhan..

## Hari ke-6

Pada hari ke-6, saya merasa lebih baik.. Namun belum bisa melakukan aktifitas seperti biasa.

## Hari ke-7

Pada hari ke-7, saya merasa seperti normal kembali. Kembali menikmati kopi dan menulis blog.

Akan tetapi, selama tujuh hari ini saya tidak pernah coding. Hasilnya, akun github saya kosong selama 7 hari.

![github 7 hari](/img/sakit-2021/github-7-hari.png)

## Akhir Kata..

Semoga yang membaca blog ini diberikan kesehatan :pray: