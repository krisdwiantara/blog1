---
title: "Hasil Latihan Belajar Menggambar Selama Satu Bulan"
slug: satu-bulan-menggambar
date: 2018-04-21T15:27:53+08:00
draft: false

type: post

tags:
    - art
    - hobi

image: "/img/draw/karya-dian.png"
description: "Sudah satu bulan saya belajar menggambar dan inilah hasilnya ..."
---

Sejak tanggal 18 maret yang lalu, saya tidak sengaja mencorat-coret kertas
bekas dengan pensil. Melihat hasilnya yang cukup bagus, saya tertarik
lagi untuk menggambar.

{{< tweet 975143918600839168 >}}

Menggambar adalah hobi saya sejak SD dan SMP.

Lalu, saat masuk SMK dan kuliah, saya tidak menggambar lagi.
Karena mungkin tidak ada teman yang sehobi dengan saya.

Lalu beberapa waktu yang lalu, saya menemukan video tutorial
menggambar manga di Youtube.

Video tersebut mengajari cara menggambar proprsi tubuh,
dan lain-lain.

Sepertinya sangat mudah dimengerti...

Ini membuat saya semakin tertarik untuk menggambar.

Saya akhirnya membeli beberapa peralatan seperti
pensil, buku gambar, dan sketch book.

Lalu latihan corat-coret, dan inilah hasil latihan
selema bulan ini:

![Hasil gambar selama bulan april 2018](/img/draw/karya-dian.png)

Gambar-gambar yang sudah saya buat, dapat dilihat di
galeri [Devian Art](https://ardiantapargo.deviantart.com/) saya dan [Album foto di facebook](https://www.facebook.com/ardianta.pargo/media_set?set=a.2137664869584207.1073741834.100000221442854&type=3).

## Kesulitan

Saya masih merasa kesulitan menggambar proporsi tubuh, rambut, dan membuat _shading_.

Sewaktu menggambar menggunakan aplikasi di HP, saya kesulitan karena masih menggunakan
jari 😄. Belum punya pen stylus...

Rencananya dalam waktu dekat ini, saya akan membli wacom untuk menggambar di komputer.

## Tantangan

Saat ini saya cukup sibuk, beberapa pekerjaan belum diselesaikan.

{{< tweet 987569759343407106 >}}

Akankah saya punya waktu untuk menggambar... 🤔

Meskipun tak dibayar. 😄

Yang namanya hobi, nggk dibayar juga nggak apa-apa.
Yang penting kita senang melakukannya.

Jelek dan bagusnya sebuah gambar, itu adalah hasil latihan. 
Semakin sering latihan, maka insya'allah hasilnya akan semakin bagus.

Apapun hasilnya, saya akan terus menggambar (mudah-mudahan tetap konsisten).