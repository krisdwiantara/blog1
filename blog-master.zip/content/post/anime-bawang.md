---
title: "Anime Bawang"
slug: anime-bawang
date: 2021-07-07T21:44:52+08:00
draft: false

type: post

tags:
    - Anime

image: "/img/anime-bawang/anime-bawang.jpeg"
description: "Beberapa Anime kadang membuat kita menangis, terharu, dan sedih.
Saya menyebutnya Anime bawang."

typora-root-url: ../../static
---

Beberapa Anime kadang membuat kita menangis, terharu, dan sedih.
Saya menyebutnya *Anime bawang*.

Saya akan membagikan beberapa anime bawang yang mungkin bisa membuatmu menangis.
Setiap anime akan saya berikan rating bawang 1--5 dengan emoji 🧅.

1. 🧅 : bisa membuat mata berkaca-kaca;
2. 🧅🧅 : air mata keluar dari kelopak mata dan butuh tisu;
3. 🧅🧅🧅 : air mata keluar, dan juga air mata keluar dari hidung (mungkin namanya ingus);
4. 🧅🧅🧅🧅 : Kamu nangis sampai bersuara;
5. 🧅🧅🧅🧅🧅 : Kamu nangis sampai teriak.

Rating ini bersifat relatif dan subjektif, tergantung situasi dan kondisi emosi yang menonton.

Rating yang saya berikan di sini berdasarkan pengalaman seniri hehe.

Oke..

Baiklah!

Ini beberapa Anime bawang yang saya rekomendasikan untuk ditonton:

## 1. One Piece

Bawang: 🧅🧅🧅

Beberapa adegan yang mengandung bawang:

- Saat Vivi berteriak untuk menghentikan perang di arabasta
- Saat kematian Ace
- Saat pembakaran Going Merry
- dll.


## 2. Naruto Shippuden

Bawang: 🧅

## 3. AIR

Bawang: 🧅🧅

Bawangnya ada di ending. Episode awal-awal biasa saja. Tapi baiknya nonton
aja semua episodenya biar dapat rasa bawangnya hehe.

## 4. Angel Beats

Bawang: 🧅🧅🧅

Bawangnya ada di ending. Di tengah-tengah juga ada bawangnya, cuma rasanya mungkin berbeda.

## 5. Tokyo Magnitude 8.0

Bawang: 🧅🧅🧅

Bagi yang pernah punya mengalaman dan trauma gempa, mungkin anime ini akan
membuatmu menangis hehe.

## 6. Nihon Chinbotsu 2020

Bawang: 🧅🧅

Hampir sama seperti *Tokyo Magnitude 8.0*, hanya saja bawangnya terdapat di episode 1.
Sisanya survival dan agak aneh sih menurut saya.

## 7. Fumetsu no Anata e

Bawang: 🧅🧅🧅

Anime ini banyak kandungan bawangnya dan ceritanya menarik.

## 8. Violet Evergarden

Bawang: 🧅🧅🧅

Saat nonton movie Violet Evergarden di Bioskop, saya kurang bisa menikmati rasa bawangnya. Mungkin karena rame dan gak bawa tisu hehe.

Tapi kalau nonton sendirian, yah bisa terasa bawangnya.

## 9. Kimi no Nawa

Bawang: 🧅🧅

## 10. Tenki no Ko

Bawang: 🧅

## 11. Wolf Children

Bawang: 🧅🧅

## 12. Shigatsu wa kimi no uso

Bawang: 🧅

## 13. I Want to Eat Your Pancreas

Bawang: 🧅🧅🧅

## Akhir Kata..

Cukup sekian dulu, nanti saya tambahkan lagi.. dan tunggulah update berikutnya. 
Saya coba ingat-ingat dulu anime apa saja yang membuat saya mengeluarkan air mata 
atau nangis hehe :smile:.

**Menangis adalah cara alami membersihkan mata dari debu dan kotoran serangga.** – Dian

Dari pada beli ini:

![Obat Mata Merah yang Bantu Penglihatan Kembali Jernih](/img/anime-bawang/obat-mata-merah-yang-efektif-untuk-hilangkan-sakit-mata-1570438331.jpg)

Mending menangis aja!

Selamat menangis..
