---
title: "Keyboard Mechanical Pertama Saya"
slug: keyboard-mechanical-pertama
date: 2021-04-07T16:23:09+08:00
draft: false

type: post

tags:
    - keyboard

image: ""
description: "Cerita tentang keyboard mechanical pertama yang saya miliki"

typora-root-url: ../../static
---

Hari ini saya menerima dua paket secara bersamaan. Paket pertama adalah Keyboard 
yang saya pesan dari Shopee dan paket yang kedua adalah buku dari BBW Tokopedia.

Rexus Legionare MX5.1, ini adalah keyboard mechanikal pertama yang saya miliki. 
Harganya murah sekitar 300 ribuan.

Awalnya saya memesan yang brown switch, karena ingin coba mengetik dengan suara 
yang tidak ribut dan dapat feedback dari switch-nya.

Akan tetapi, stok yang brown sudah habis. 

Akhirnya ditelpon pihak toko untuk konfirmasi dan saya pun menggantinya dengan 
red switch.

Pengalaman mengetik dengan red switch sungguh luar biasa. 
Rasanya seperti melakukan touch typing, karena tidak perlu banyak tenaga untuk 
menekan tombol. Cukup sentuh sedikit saja hehe.

Saya merasa bersemangat mengetik dengan keyboard ini.. hoho this is spark joy.

Keyboard ini sbenarnya untuk gaming, dilihat dari desainnya dengan lampu RGB 
yang menarik. Namun, saya jarang main game. Lebih banyak ngetik dan nulis kode.

Sepertinya keyboard ini akan banyak saya gunakan untuk ngetik kode dan artikel.

Setelah ini mungkin saya ingin coba switch yang lain seperti blue dan brown. 
Tapi kalau dilihat di review Youtube.. blue terdengar seperti suara mesin tik 
dan brown terdengar lebih lembut.

Mungkin nanti kalau ada budget saya akan coba switch tersebut dan mungkin juga 
akan coba build custom keyboard sendiri. Karena beberapa teman saya sudah build 
keyboard mereka sendiri.

Nah, sekian dulu blog kali ini..

Oh iya, tulisan ini diketik dengan keyboard mechanical pertama saya hehe.